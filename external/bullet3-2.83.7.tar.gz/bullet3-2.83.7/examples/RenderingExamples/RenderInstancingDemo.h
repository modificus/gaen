#ifndef RENDER_INSTANCING_DEMO_H
#define RENDER_INSTANCING_DEMO_H

class CommonExampleInterface*    RenderInstancingCreateFunc(struct CommonExampleOptions& options);

#endif //RENDER_INSTANCING_DEMO_H
